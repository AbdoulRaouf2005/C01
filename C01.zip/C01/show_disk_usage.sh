#!/bin/bash
df -h
exit 0