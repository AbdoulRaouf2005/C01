#!/bin/bash
df -h
du
exit 0